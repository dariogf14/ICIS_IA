import React from 'react';
// TODO: Importa el componente UserCard


function UserSelectionScreen() {
  // TODO: Recibe las props adecuadas

  return (
    <div className="user-selection-container">
      <div className="user-selection-header">
        <h1>Bienvenido al Gestor de Finanzas</h1>
        <p>Por favor, selecciona un usuario para continuar</p>
      </div>
      <div className="user-selection-grid">
        {/* 
          TODO: Mapea el array de usuarios...
         
        */}
      </div>
    </div>
  );
}

export default UserSelectionScreen;
